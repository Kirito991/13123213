const Discord = require("discord.js");
const client = new Discord.Client();
client.login("NDUyODU1NjYwNzc0Njg2NzIw.D3kOig.XGYpfwajyHSHmjVAz3ba_mobT_0");
client.on("message", (message) => { //В случае если бот заметит новое сообщение (message)..
if(message.content == "!privet"){ //Он проверит если его контент (content) равняется фразе "!privet"
message.reply("Привет! :wave:"); //И в случае если так и есть он ответит на сообщение фразой Привет! и отправит смайлик
} //Закрытие условия
}); //Закрытие события
